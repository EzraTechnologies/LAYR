import base from '/workspace/work/layr-combined-20261104.1/source/playwright.config';
export default {
  ...base,
  testDir: '/workspace/work/layr-combined-20261104.1/source/e2e',
  outputDir: '/workspace/work/layr-combined-20261104.1/browser-results',
  workers: 1,
  webServer: { ...base.webServer, command: 'npx vite preview --port 4174 --strictPort --host 127.0.0.1', cwd: '/workspace/work/layr-combined-20261104.1/source', reuseExistingServer: false },
  projects: base.projects?.map(project => ({ ...project, use: { ...project.use, launchOptions: { executablePath: '/usr/bin/chromium' } } })),
};
