import base from '/workspace/work/layr-combined-20261104.1/source/playwright.auth.config';
export default {
  ...base,
  testDir: '/workspace/work/layr-combined-20261104.1/source/e2e',
  outputDir: '/workspace/work/layr-combined-20261104.1/auth-results',
  workers: 1,
  webServer: { ...base.webServer, command: 'npm run build -- --outDir /workspace/work/layr-combined-20261104.1/auth-dist --emptyOutDir && npx vite preview --outDir /workspace/work/layr-combined-20261104.1/auth-dist --port 4175 --strictPort --host 127.0.0.1', cwd: '/workspace/work/layr-combined-20261104.1/source', reuseExistingServer: false },
  projects: base.projects?.map(project => ({ ...project, use: { ...project.use, launchOptions: { executablePath: '/usr/bin/chromium' } } })),
};
